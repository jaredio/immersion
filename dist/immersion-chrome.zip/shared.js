/* Shared by the popup and isolated content script. No remote dependencies. */
(() => {
  const compactNumber=new Intl.NumberFormat('en-US',{notation:'compact',maximumFractionDigits:1}).format;
  const defaults = Object.freeze({
    enabled: true,
    performance: true,
    fastChat: false,
    blockTelemetry: true,
    diagnostics: false,
    compact: false,
    hideRecommended: false,
    textOnly: false,
    chatClips: true,
    xEmbeds: true,
    mediaEmbeds: true,
    chatWidth: 340,
    fontSize: 14,
    accent: 'mint',
    pinned: []
  });
  function normalize(input = {}) {
    const source = input && typeof input === 'object' ? input : {};
    const result = { ...defaults };
    for (const key of ['enabled', 'performance', 'fastChat', 'blockTelemetry', 'diagnostics', 'compact', 'hideRecommended', 'textOnly', 'chatClips', 'xEmbeds', 'mediaEmbeds']) {
      if (typeof source[key] === 'boolean') result[key] = source[key];
    }
    for (const [key, min, max] of [['chatWidth', 280, 440], ['fontSize', 12, 18]]) {
      if (Number.isFinite(source[key])) result[key] = Math.min(max, Math.max(min, Math.round(source[key])));
    }
    if (['mint', 'violet', 'blue', 'neutral'].includes(source.accent)) result.accent = source.accent;
    const pinned = new Set();
    if (Array.isArray(source.pinned)) for (const value of source.pinned) {
      if (typeof value === 'string' && /^[a-zA-Z0-9_]{1,40}$/.test(value)) pinned.add(value.toLowerCase());
      if (pinned.size === 30) break;
    }
    result.pinned = [...pinned];
    return result;
  }
  const reserved = new Set(['browse', 'categories', 'category', 'following', 'search', 'settings', 'dashboard', 'auth', 'login', 'signup', 'register', 'events', 'clips', 'videos', 'subscriptions', 'transactions', 'wallet', 'drops', 'legal', 'community-guidelines', 'terms-of-service', 'privacy-policy', 'about', 'download', 'rewards', 'account', 'moderator', 'moderation', 'kicks', 'inventory', 'popout']);
  function channelSlug(href, origin = 'https://kick.com') {
    try {
      const url = new URL(href, origin);
      if (url.origin !== origin || url.search || url.hash) return null;
      const match = /^\/([a-zA-Z0-9_]{1,40})\/?$/.exec(url.pathname);
      return match && !reserved.has(match[1].toLowerCase()) ? match[1].toLowerCase() : null;
    } catch { return null; }
  }
  const api = typeof browser !== 'undefined' ? browser : typeof chrome !== 'undefined' ? chrome : null;
  // Keep chat cards aligned even when Kick lays out a message with flex children.
  const chatEmbedCSS = `
    :host(:not([data-workspace])){display:block;width:100%;min-width:0;max-width:100%;flex:0 0 100%}
    :host(:not([data-workspace])) .card{box-sizing:border-box;width:calc(100% - 16px);max-width:348px;margin:8px auto 6px;border:1px solid #ffffff14;border-radius:12px;background:#121216;transition:border-color .16s ease,background-color .16s ease,box-shadow .16s ease}
    :host(:not([data-workspace])) .card:focus-within{border-color:color-mix(in srgb,var(--kr-accent,#b0ff8c) 32%,transparent);background:#16161c;box-shadow:0 0 0 1px #ffffff03}
    @media(hover:hover) and (pointer:fine){:host(:not([data-workspace])) .card:hover{border-color:color-mix(in srgb,var(--kr-accent,#b0ff8c) 32%,transparent);background:#16161c;box-shadow:0 0 0 1px #ffffff03}}
    @media(prefers-reduced-motion:reduce){:host(:not([data-workspace])) .card{transition:none}}
  `;
    const embedRows=new WeakMap();let embedMessageStyle;
    function chatEmbedMessage(row){
      if(!embedMessageStyle){embedMessageStyle=document.createElement('style');embedMessageStyle.textContent='#chatroom-messages [data-kr-embed-row]{flex-wrap:wrap;row-gap:0;overflow-wrap:anywhere;box-shadow:inset 2px 0 #ffffff10;border-radius:3px}#chatroom-messages [data-kr-embed-row]>:is(.kr-chat-clip,.kr-x-post,.kr-media-embed){margin-top:2px}';document.head.append(embedMessageStyle);}
      embedRows.set(row,(embedRows.get(row)||0)+1);row.setAttribute('data-kr-embed-row','');
      let released=false;return ()=>{if(released)return;released=true;const count=(embedRows.get(row)||1)-1;if(count)embedRows.set(row,count);else{embedRows.delete(row);row.removeAttribute('data-kr-embed-row');}};
    }
    function multiState(input = {}) {
    const source = input && typeof input === 'object' ? input : {};
    const channels = [];
    if (Array.isArray(source.channels)) for (const value of source.channels) {
      if (typeof value !== 'string' || !/^[a-zA-Z0-9_]{1,40}$/.test(value)) continue;
      const slug = channelSlug(`/${value}`); if (slug && !channels.includes(slug)) channels.push(slug);
      if (channels.length === 6) break;
    }
    const sizes=Object.create(null);for(const slug of channels)if(Number.isFinite(source.sizes?.[slug]))sizes[slug]=Math.max(2,Math.min(6,Math.round(source.sizes[slug])));
    const playerModes=Object.create(null);for(const slug of channels)if(['full','embed'].includes(source.playerModes?.[slug]))playerModes[slug]=source.playerModes[slug];
    return { channels, sizes, playerModes, playerMode:source.playerMode==='embed'?'embed':'full',mixAudio:source.mixAudio===true, layout: ['grid', 'focus', 'columns'].includes(source.layout) ? source.layout : 'grid', chat: channels.includes(source.chat) ? source.chat : channels[0] || '', chatVisible: source.chatVisible !== false, focus: channels.includes(source.focus) ? source.focus : channels[0] || '', focusSize: Number.isFinite(source.focusSize) ? Math.max(45,Math.min(80,Math.round(source.focusSize))) : 74 };
  }
  function multiURL(input) {
    const state = multiState(input), url = new URL('https://kick.com/');
    url.searchParams.set('refined-multi', state.channels.join(',')); url.searchParams.set('refined-layout', state.layout);
    url.searchParams.set('refined-chat', state.chat); url.searchParams.set('refined-focus', state.focus);
    url.searchParams.set('immersion-size',state.focusSize);
    url.searchParams.set('immersion-player',state.playerMode);
    if(Object.keys(state.playerModes).length)url.searchParams.set('immersion-players',JSON.stringify(state.playerModes));
    if(state.mixAudio)url.searchParams.set('immersion-mix','1');
    if(Object.keys(state.sizes).length)url.searchParams.set('immersion-tiles',JSON.stringify(state.sizes));
    if (!state.chatVisible) url.searchParams.set('refined-hide-chat', '1');
    return url.href;
  }
  function channelDetails(data,slug){
    if(!data||typeof data!=='object'||typeof data.slug!=='string'||data.slug.toLowerCase()!==slug)return null;
    const text=value=>typeof value==='string'?value.trim().slice(0,600):'';
    const user=data.user||{},stream=data.livestream,category=stream?.categories?.[0]?.name||data.recent_categories?.[0]?.name;
    const socials=[];
    const platforms={twitter:['X','https://x.com/',['x.com','twitter.com']],instagram:['Instagram','https://www.instagram.com/',['instagram.com']],youtube:['YouTube','https://www.youtube.com/@',['youtube.com','youtu.be']],discord:['Discord','https://discord.gg/',['discord.gg','discord.com']],tiktok:['TikTok','https://www.tiktok.com/@',['tiktok.com']],facebook:['Facebook','https://www.facebook.com/',['facebook.com']]};
    for(const [key,[label,base,hosts]]of Object.entries(platforms)){
      const value=text(user[key]);if(!value)continue;
      try{const href=/^https?:\/\//i.test(value)?new URL(value):/^[\w.@-]{1,120}$/.test(value)?new URL(base+encodeURIComponent(value.replace(/^@/,''))):null;
        if(href?.protocol==='https:'&&hosts.some(host=>href.hostname===host||href.hostname.endsWith('.'+host))&&!href.username&&!href.password)socials.push({label,href:href.href});
      }catch{}
    }
    let image='';try{const url=new URL(user.profile_pic);if(url.protocol==='https:'&&url.hostname.endsWith('.kick.com'))image=url.href;}catch{}
    const clock=globalThis.KickRefinedStreamClock,startedAt=stream&&stream.is_live!==false?(clock?.parse(stream.start_time)??clock?.parse(stream.started_at)??clock?.parse(stream.created_at)??null):null;
    const rawFollowers=data.followers_count??data.followersCount;
    const count=typeof rawFollowers==='string'&&/^\d+$/.test(rawFollowers)?Number(rawFollowers):rawFollowers;
    const followers=Number.isSafeInteger(count)&&count>=0?compactNumber(count):'';
    return {startedAt,title:text(user.username)||slug,streamTitle:text(stream?.session_title),bio:typeof user.bio==='string'?user.bio.trim().slice(0,20000):'',category:text(category),language:text(stream?.language).slice(0,30),mature:stream?.is_mature===true,verified:data.verified===true||!!data.verified&&typeof data.verified==='object',live:stream?.is_live===true?'live':data.livestream===null?'offline':'unknown',viewers:Number.isFinite(stream?.viewer_count)&&stream.viewer_count>=0?Math.floor(stream.viewer_count).toLocaleString('en-US'):'',followers,image,socials};
  }
  async function readText(response,{maxBytes=2097152,signal}={}) {
    const aborted=()=>signal?.throwIfAborted();
    // Cancellation is best effort: an unresponsive source must not block rejection.
    const cancel=body=>{void body?.cancel().catch(()=>{});};
    if(signal?.aborted){cancel(response.body);aborted();}
    if(Number(response.headers.get('content-length'))>maxBytes){cancel(response.body);throw Error('Response is too large.');}
    aborted();if(!response.body)return '';
    const reader=response.body.getReader(),decoder=new TextDecoder();let bytes=0,text='';
    const stop=()=>cancel(reader);
    signal?.addEventListener('abort',stop,{once:true});
    try{
      aborted();
      while(true){const {done,value}=await reader.read();aborted();if(done)break;
        bytes+=value.byteLength;if(bytes>maxBytes){stop();throw Error('Response is too large.');}
        text+=decoder.decode(value,{stream:true});
      }
      return text+decoder.decode();
    }finally{signal?.removeEventListener('abort',stop);reader.releaseLock();}
  }
  globalThis.KickRefined = Object.freeze({ defaults, normalize, channelSlug, api, chatEmbedCSS, chatEmbedMessage, multiState, multiURL, channelDetails, readText });
})();
