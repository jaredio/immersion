/* Public Kick search with bounded requests, explicit query syntax and no API keys. */
(() => {
  const slug=value=>typeof value==='string'&&/^[a-z0-9_]{1,40}$/i.test(value)?value.toLowerCase():'';
  const alias=(values,key)=>Object.hasOwn(values,key)?values[key]:null;
  function parse(input='',{allowUnscoped=false}={}){
    if(typeof input!=='string'||input.length>512)throw Error('Keep the query under 512 characters.');
    input=input.trim();if(/^https:\/\/(?:www\.)?kick\.com\/[\w]+\/?$/i.test(input))input=new URL(input).pathname.slice(1).replace(/\/$/,'');
    const tokens=[];let token='',quoted=false,escape=false,literal=false;
    for(const char of input){if(escape){token+=char;escape=false;}else if(char==='\\'&&quoted)escape=true;else if(char==='"'){if(!token)literal=true;quoted=!quoted;}else if(/\s/.test(char)&&!quoted){if(token)tokens.push({value:token,literal});token='';literal=false;}else token+=char;}
    if(quoted||escape)throw Error('Close the quotation marks to search.');if(token)tokens.push({value:token,literal});
    const q={type:'channels',channels:[],terms:[],exclude:[],sort:'recent',time:'all',live:null,after:null,before:null,category:'',creator:'',views:null,duration:null};let kind='';
    function setType(value){const next=alias({channel:'channels',channels:'channels',clip:'clips',clips:'clips',vod:'vods',vods:'vods',video:'vods',videos:'vods'},value);if(!next)throw Error('Use type:channels, type:clips or type:vods.');if(kind&&kind!==next)throw Error('Search one type at a time: channels, clips or VODs.');kind=q.type=next;}
    function channels(value){for(const part of value.split(',')){const name=slug(part.replace(/^@/,''));if(!name)throw Error('Use a channel name after the colon.');if(!q.channels.includes(name))q.channels.push(name);}if(q.channels.length>3)throw Error('Search up to three channels at once.');}
    function date(value){if(!/^\d{4}-\d{2}-\d{2}$/.test(value))throw Error('Dates use YYYY-MM-DD.');const time=Date.parse(value+'T00:00:00Z');if(!Number.isFinite(time)||new Date(time).toISOString().slice(0,10)!==value)throw Error('Enter a valid date.');return time;}
    for(const entry of tokens){const token=entry.value,match=entry.literal?null:/^([a-z]+):(.*)$/i.exec(token);if(!match){if(token.startsWith('-')&&token.length>1)q.exclude.push(token.slice(1).toLowerCase());else q.terms.push(token.toLowerCase());continue;}const key=match[1].toLowerCase(),value=match[2],lower=value.toLowerCase();
      if(['clips','clip','vods','vod','videos','channels'].includes(key)){setType(key);channels(lower);}
      else if(key==='type')setType(lower);
      else if(['channel','in'].includes(key))channels(lower);
      else if(key==='sort'){q.sort=alias({recent:'recent',date:'recent',newest:'recent',views:'views',popular:'views'},lower);if(!q.sort)throw Error('Use sort:recent or sort:views.');}
      else if(key==='time'){q.time=alias({day:'day','24h':'day',week:'week','7d':'week',month:'month','30d':'month',all:'all'},lower);if(!q.time)throw Error('Use time:day, week, month or all.');}
      else if(key==='live'){if(!['true','false','yes','no'].includes(lower))throw Error('Use live:true or live:false.');q.live=['true','yes'].includes(lower);}
      else if(key==='after')q.after=date(value);
      else if(key==='before')q.before=date(value)+86400000-1;
      else if(key==='category')q.category=lower;
      else if(key==='creator'){q.creator=slug(lower.replace(/^@/,''));if(!q.creator)throw Error('Use a username with creator:.');}
      else if(['views','duration'].includes(key)){const limit=/^(>=|<=|>|<|=)?(\d{1,10})$/.exec(value);if(!limit)throw Error(`Use ${key}:>100 or ${key}:<100.`);q[key]={op:limit[1]||'>=',value:Number(limit[2])};}
      else throw Error(`Unknown filter: ${key}:. Open ? for supported filters.`);
    }
    if(q.type!=='channels'&&!q.channels.length&&!allowUnscoped)throw Error(`Choose a channel, for example ${q.type}:cobbruvs.`);
    if(q.type==='channels'&&(q.creator||q.duration||q.after!==null||q.before!==null||q.time!=='all'))throw Error('Date, duration and creator filters need clips:channel or vods:channel.');
    if(q.type!=='channels'&&q.live!==null)throw Error('live: filters channel results.');if(q.type!=='clips'&&q.creator)throw Error('creator: filters clips.');if(q.after!==null&&q.before!==null&&q.after>q.before)throw Error('after: must come before before:.');return q;
  }
  function serialize(q){
    const quote=value=>'"'+value.replace(/\\/g,'\\\\').replace(/"/g,'\\"')+'"';
    const tokens=q.terms.map(quote).concat(q.exclude.map(value=>quote('-'+value)));
    if(q.type!=='channels')tokens.unshift(q.channels.length?`${q.type}:${q.channels.join(',')}`:`type:${q.type}`);else if(q.channels.length)tokens.unshift(`channel:${q.channels.join(',')}`);
    if(q.live!==null)tokens.push(`live:${q.live}`);if(q.sort==='views')tokens.push('sort:views');if(q.time!=='all')tokens.push(`time:${q.time}`);
    for(const key of ['category','creator'])if(q[key])tokens.push(`${key}:${quote(q[key])}`);
    for(const key of ['after','before'])if(q[key]!==null)tokens.push(`${key}:${new Date(q[key]).toISOString().slice(0,10)}`);
    for(const key of ['views','duration'])if(q[key])tokens.push(`${key}:${q[key].op}${q[key].value}`);
    return tokens.join(' ');
  }
  function rank(rows,q,pinned=[]){
    if(q.sort==='views')return [...rows].sort((a,b)=>(b.views??-1)-(a.views??-1));
    const term=q.terms.join(' ').toLowerCase(),pins=new Set(pinned);
    const score=row=>(term&&row.slug===term?1000:term&&row.slug.startsWith(term)?500:0)+(pins.has(row.slug)?100:0)+(row.live==='live'?10:0);
    return rows.map(row=>({row,score:score(row)})).sort((a,b)=>b.score-a.score).map(item=>item.row);
  }
  const count=value=>{if(typeof value==='string'&&/^\d{1,15}$/.test(value))value=Number(value);return Number.isSafeInteger(value)&&value>=0?value:null;};
  const text=(value,max=500)=>typeof value==='string'?value.replace(/\s+/g,' ').trim().slice(0,max):'';
  function image(value){try{if(typeof value!=='string'||value.length>4096)return '';const url=new URL(value);return url.protocol==='https:'&&!url.username&&!url.password&&!url.port&&(url.hostname==='kick.com'||url.hostname.endsWith('.kick.com'))?url.href:'';}catch{return '';}}
  function duration(value){if(!Number.isFinite(value)||value<0)return '';const seconds=Math.floor(value);return seconds>=3600?`${Math.floor(seconds/3600)}:${String(Math.floor(seconds/60)%60).padStart(2,'0')}:${String(seconds%60).padStart(2,'0')}`:`${Math.floor(seconds/60)}:${String(seconds%60).padStart(2,'0')}`;}
  function catalog(html,channel){
    if(typeof html!=='string'||!slug(channel))throw Error('Recordings unavailable.');const doc=new DOMParser().parseFromString(html,'text/html'),rows=[];
    for(const card of [...doc.querySelectorAll('[data-testid="vods-card"]')].slice(0,200)){
      const thumbnail=card.querySelector('a[data-testid="media-card-thumbnail"]');if(!thumbnail)continue;let url;try{url=new URL(thumbnail.getAttribute('href'),'https://kick.com');}catch{continue;}
      const match=new RegExp(`^/${channel}/videos/([\\da-f]{8}(?:-[\\da-f]{4}){3}-[\\da-f]{12})/?$`,'i').exec(url.pathname);if(!match||url.origin!=='https://kick.com')continue;
      const clock=[...thumbnail.querySelectorAll('div')].map(node=>node.textContent.trim()).find(value=>/^\d{1,3}(?::\d{2}){1,3}$/.test(value));if(!clock)continue;const parts=clock.split(':').map(Number),seconds=(parts.length===4?parts.shift()*86400:0)+parts.reduce((total,value)=>total*60+value,0);
      const heading=[...card.querySelectorAll('a[title]')].find(node=>node.getAttribute('href')===thumbnail.getAttribute('href'));
      const views=[...thumbnail.querySelectorAll('span[title]')].map(node=>node.getAttribute('title')).find(value=>/^\d+$/.test(value));
      const stamp=[...card.querySelectorAll('span[title]')].map(node=>node.getAttribute('title')).find(value=>/^\d{1,2}\/\d{1,2}\/\d{4},/.test(value));let created=0;
      const date=/^(\d{1,2})\/(\d{1,2})\/(\d{4}),\s*(\d{1,2}):(\d{2})\s*([AP]M)$/.exec(stamp||'');if(date&&Number(date[1])<=12&&Number(date[2])<=31&&Number(date[4])<=12&&Number(date[5])<60)created=Date.UTC(Number(date[3]),Number(date[1])-1,Number(date[2]),Number(date[4])%12+(date[6]==='PM'?12:0),Number(date[5]));
      rows.push({key:'vod:'+match[1],type:'vod',slug:channel,title:text(heading?.getAttribute('title')||card.querySelector('h3')?.textContent)||'Untitled recording',href:`https://kick.com/${channel}/videos/${match[1]}`,image:image(thumbnail.querySelector('img[data-thumbnail],img')?.getAttribute('src')),category:text(card.querySelector('a[href^="/category/"]')?.textContent,100),views:count(views),duration:seconds,created});
    }if(!rows.length&&!/video|vod|recording/i.test(doc.querySelector('title')?.textContent||''))throw Error('Kick recordings are unavailable. Try again.');return rows;
  }
  function normalize(raw,type,channel=''){
    if(!raw||typeof raw!=='object')throw Error('Kick returned an unavailable search response.');
    let list=type==='channels'?(Array.isArray(raw.channels)?raw.channels:[raw]):type==='clips'?raw.clips:raw;
    if(!Array.isArray(list))throw Error('Kick returned an unavailable search response.');const rows=[];
    for(const item of list.slice(0,300)){if(!item||typeof item!=='object')continue;
      if(type==='channels'){
        const name=slug(item.slug);if(!name||item.is_banned)continue;const live=item.isLive??item.livestream?.is_live;
        rows.push({key:'channel:'+name,type:'channel',slug:name,title:text(item.user?.username)||name,image:image(item.user?.profilePic||item.user?.profile_pic),href:`https://kick.com/${name}`,category:text(item.livestream?.categories?.[0]?.name||item.recentCategories?.[0]?.name||item.recent_categories?.[0]?.name,100),streamTitle:text(item.livestream?.session_title),live:live===true?'live':live===false||item.livestream===null?'offline':'unknown',views:count(item.livestream?.viewer_count),section:'Kick search'});
      }else if(type==='clips'){
        if(!/^clip_[a-z0-9]{26}$/i.test(item.id)||item.is_private||item.privacy&&item.privacy!=='public'||slug(item.channel?.slug)&&slug(item.channel.slug)!==channel)continue;
        rows.push({key:'clip:'+item.id,type:'clip',slug:channel,title:text(item.title)||'Untitled clip',image:image(item.thumbnail_url),href:`https://kick.com/${channel}/clips/${item.id}`,category:text(item.category?.name,100),creator:slug(item.creator?.slug||item.creator?.username),views:count(item.views??item.view_count),duration:count(Math.floor(item.duration)),created:Date.parse(item.created_at)||0});
      }else{throw Error('Unsupported search response.');
      }
    }return rows;
  }
  function fits(row,q){
    const haystack=[row.title,row.slug,row.streamTitle,row.category].filter(Boolean).join(' ').toLowerCase();
    if(q.terms.some(term=>!haystack.includes(term))||q.exclude.some(term=>haystack.includes(term)))return false;
    if(q.channels.length&&!q.channels.includes(row.slug)||q.category&&!row.category?.toLowerCase().includes(q.category)||q.creator&&row.creator!==q.creator)return false;
    if(q.live!==null&&row.live!==(q.live?'live':'offline'))return false;
    if((q.after!==null||q.before!==null)&&!row.created||q.after!==null&&row.created<q.after||q.before!==null&&row.created>q.before)return false;
    if(q.time!=='all'&&(!row.created||row.created<Date.now()-{day:86400000,week:604800000,month:2592000000}[q.time]))return false;
    for(const key of ['views','duration'])if(q[key]){const value=row[key],limit=q[key];if(value===null||value===undefined)return false;if(!({'>':value>limit.value,'>=':value>=limit.value,'<':value<limit.value,'<=':value<=limit.value,'=':value===limit.value}[limit.op]))return false;}return true;
  }
  const cache=new Map(),pending=new Map();
  async function read(path,signal,decode){
    signal.throwIfAborted();
    const url=location.origin+path,hit=cache.get(url);
    if(hit?.until>Date.now())return hit.data;
    let request=pending.get(url);
    if(!request){
      const controller=new AbortController(),requestSignal=AbortSignal.any([controller.signal,AbortSignal.timeout(8000)]);
      request={controller,waiters:0,promise:null};
      const entry=request;
      pending.set(url,entry);
      entry.promise=(async()=>{
        globalThis.KickRefinedPerf?.count('network.searchRequests');
        const response=await fetch(url,{credentials:'omit',referrerPolicy:'no-referrer',signal:requestSignal});
        if(!response.ok)throw Error('Kick search is unavailable. Try again.');
        const body=await KickRefined.readText(response,{signal:requestSignal});
        requestSignal.throwIfAborted();
        const data=decode(body);
        cache.delete(url);cache.set(url,{until:Date.now()+45000,data});while(cache.size>20)cache.delete(cache.keys().next().value);
        return data;
      })().finally(()=>{if(pending.get(url)===entry)pending.delete(url);});
    }
    request.waiters++;
    let abort;
    try{
      return await new Promise((resolve,reject)=>{
        abort=()=>reject(signal.reason);
        signal.addEventListener('abort',abort,{once:true});
        request.promise.then(resolve,reject);
        if(signal.aborted)abort();
      });
    }finally{
      signal.removeEventListener('abort',abort);
      if(--request.waiters===0&&pending.get(url)===request){
        pending.delete(url);
        request.controller.abort();
      }
    }
  }
  function create(){
    let active=null,state=null,disposed=false;
    function cancel(){active?.abort();active=null;}
    function json(body){try{return JSON.parse(body);}catch{throw Error('Kick search is unavailable. Try again.');}}
    async function search(q,{append=false,retryFailed=false}={}){
      if(disposed)throw Error('Search closed.');cancel();const controller=new AbortController();active=controller;const key=JSON.stringify(q);
      if((!append&&!retryFailed)||state?.key!==key)state={key,rows:new Map(),progress:q.channels.map(channel=>({channel,cursor:'',cursors:new Set(),pages:0,loaded:0,done:false}))};const current=state;
      if(q.type==='channels'){
        if(!q.channels.length&&!q.terms.length)return {rows:[],more:false};
        if(!q.channels.length){const results=await read('/api/search?'+new URLSearchParams({searched_word:q.terms.join(' ')}),controller.signal,body=>{
          const data=json(body);if(!Array.isArray(data?.channels)&&!slug(data?.slug))throw Error('Kick search is unavailable. Try again.');
          return normalize(data,'channels');
        });controller.signal.throwIfAborted();const rows=results.filter(row=>fits(row,q));return {rows,more:false,failedChannels:[]};}
        const tasks=current.progress.filter(item=>retryFailed?item.failed:!item.done);let index=0;
        await Promise.all([0,1].map(async()=>{while(index<tasks.length){const item=tasks[index++];try{
          const rows=await read(`/api/v2/channels/${item.channel}`,controller.signal,body=>{
            const data=json(body),records=Array.isArray(data?.channels)?data.channels:[data];
            const match=records.slice(0,300).find(record=>slug(record?.slug)===item.channel);
            if(!match)throw Error('Kick search is unavailable. Try again.');
            return normalize({channels:[match]},'channels');
          });
          if(controller.signal.aborted)return;for(const row of rows)current.rows.set(row.key,row);item.failed=false;item.done=true;
        }catch{if(controller.signal.aborted)return;item.failed=true;}}}));
        if(controller.signal.aborted)throw new DOMException('Cancelled','AbortError');
        const rows=[...current.rows.values()].filter(row=>fits(row,q)),failedChannels=current.progress.filter(item=>item.failed).map(item=>item.channel);
        if(failedChannels.length===current.progress.length&&!current.rows.size)throw Error('Kick search is unavailable. Try again.');
        return {rows,more:false,failedChannels,warning:failedChannels.length?'Some channels could not be loaded.':''};
      }
      const tasks=current.progress.filter(item=>(retryFailed?item.failed:!item.done&&!item.failed)&&item.pages<10&&item.loaded<200);let index=0,failures=0;
      await Promise.all([0,1].map(async()=>{while(index<tasks.length){const item=tasks[index++];try{
        const params=new URLSearchParams({sort:q.sort==='views'?'view':'date',time:q.time});if(item.cursor)params.set('cursor',item.cursor);
        const path=q.type==='clips'?`/api/v2/channels/${item.channel}/clips?${params}`:`/${item.channel}/videos`;
        const {rows,next}=await read(path,controller.signal,body=>{
          if(q.type==='vods')return {rows:catalog(body,item.channel),next:''};
          const data=json(body);
          return {rows:normalize(data,q.type,item.channel),next:typeof data.nextCursor==='string'&&data.nextCursor.length<=2048?data.nextCursor:''};
        });
        if(controller.signal.aborted)return;
        for(const row of rows)current.rows.set(row.key,row);item.loaded+=rows.length;item.pages++;item.failed=false;
        item.cursors.add(item.cursor);
        item.done=q.type!=='clips'||!next||item.cursors.has(next);item.cursor=next;
      }catch{if(controller.signal.aborted)return;failures++;item.failed=true;}}}));
      if(controller.signal.aborted)throw new DOMException('Cancelled','AbortError');if(failures===tasks.length&&tasks.length&&!current.rows.size)throw Error('Kick search is unavailable. Try again.');
      const rows=[...current.rows.values()].filter(row=>fits(row,q)).sort((a,b)=>q.sort==='views'?(b.views??-1)-(a.views??-1):b.created-a.created);
      return {rows,more:current.progress.some(item=>!item.done&&!item.failed&&item.pages<10&&item.loaded<200),failedChannels:current.progress.filter(item=>item.failed).map(item=>item.channel),warning:current.progress.some(item=>item.failed)?'Some channels could not be loaded.':''};
    }
    async function recordings(channel){
      if(disposed||!slug(channel))throw Error('Recordings unavailable.');
      cancel();const controller=new AbortController();active=controller;
      const list=await read(`/api/v2/channels/${channel}/videos`,controller.signal,body=>{
        const data=json(body);if(!Array.isArray(data))throw Error('Recordings unavailable.');return data;
      });
      controller.signal.throwIfAborted();
      return list.slice(0,300).flatMap(item=>{
        const video=item?.video,id=video?.uuid;
        if(!/^[\da-f]{8}(?:-[\da-f]{4}){3}-[\da-f]{12}$/i.test(id||'')||item.is_live||video.is_private||video.deleted_at||video.is_pruned||video.status&&video.status!=='public')return [];
        const milliseconds=count(item.duration);
        return [{type:'vod',href:`https://kick.com/${channel}/videos/${id}`,title:text(item.session_title)||'Untitled recording',image:image(item.thumbnail?.src),category:text(item.categories?.[0]?.name,100),views:count(item.views??video.views),duration:milliseconds===null?null:Math.floor(milliseconds/1000),created:Date.parse(video.created_at)||0}];
      });
    }
    return {search,recordings,cancel,destroy(){disposed=true;cancel();state=null;}};
  }
  globalThis.KickRefinedSearch=Object.freeze({parse,serialize,rank,normalize,fits,image,duration,create});
})();
