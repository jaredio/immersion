/* Frame transport. Validate source, origin, session and revision before dispatch. */
(() => {
  function create({isActive, onReady, onAudioIntent, onFocus, onFullscreen, onHover, onStatus}) {
    const session = crypto.randomUUID();
    const sources = new Map();
    let revision = 0;
    let disposed = false;

    function detach(tile) {
      // A removed iframe may already have lost its contentWindow.
      for (const [source, owner] of sources) if (owner === tile) sources.delete(source);
    }

    function onMessage(event) {
      if (disposed || !isActive()) return;
      const tile = sources.get(event.source);
      if (!tile || tile.frame?.contentWindow !== event.source || event.origin !== tile.frameOrigin) return;
      globalThis.KickRefinedPerf?.count('frame.messagesReceived');
      const data = event.data;
      // Readiness is the only message before the parent has established a session.
      if (data?.type === 'kick-refined:ready') { onReady(tile); return; }
      if (data?.session !== session) return;
      if (data.type === 'kick-refined:hover') { onHover(tile, data.hovered === true); return; }
      if (data.type === 'kick-refined:focus') { onFocus(tile); return; }
      if (data.type === 'kick-refined:fullscreen') { onFullscreen?.(tile,data.viewport,data.exit===true); return; }
      if (data.revision !== tile.commandRevision) return;
      if (data.type === 'kick-refined:audio-intent') {
        if (typeof data.muted === 'boolean' && Number.isFinite(data.volume) && data.volume >= 0 && data.volume <= 1) onAudioIntent(tile, data.muted, data.volume);
      } else if (data.type === 'kick-refined:status') onStatus(tile, data);
    }
    window.addEventListener('message', onMessage);

    return {
      attach(tile) { if (!disposed) { detach(tile); if (tile.frame?.contentWindow) sources.set(tile.frame.contentWindow, tile); } },
      detach,
      nextRevision() { return ++revision; },
      snapshot: () => ({sources: sources.size}),
      send(tile, data) {
        if (disposed) return;
        globalThis.KickRefinedPerf?.count('frame.commandsSent');
        tile.frame?.contentWindow?.postMessage({type: 'kick-refined:control', session, revision: tile.commandRevision, ...data}, tile.frameOrigin || 'https://player.kick.com');
      },
      destroy() {
        disposed = true;
        sources.clear();
        window.removeEventListener('message', onMessage);
      }
    };
  }
  globalThis.KickRefinedMultiPlayerBus = Object.freeze({create});
})();
